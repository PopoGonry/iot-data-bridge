#!/usr/bin/env python3
"""
IoT Data Bridge - MQTT Only Main Entry Point
"""

import asyncio
import logging
import signal
import sys
from pathlib import Path

# Add src directory to Python path
sys.path.insert(0, str(Path(__file__).parent))

import structlog
import yaml

from layers.input_mqtt import InputLayer
from layers.mapping import MappingLayer
from layers.resolver import ResolverLayer
from layers.transports_mqtt import TransportsLayer
from layers.logging import LoggingLayer
from catalogs.mapping_catalog import MappingCatalog
from catalogs.device_catalog import DeviceCatalog
from models.config import AppConfig
from models.events import IngressEvent, MappedEvent, ResolvedEvent, MiddlewareEventLog, DeviceIngestLog


class IoTDataBridge:
    """Main IoT Data Bridge application - MQTT Only"""
    
    def __init__(self, config_path: str = "config/app-mqtt.yaml"):
        self.config_path = config_path
        self.config = None
        self.logger = None
        self.running = False
        
        # Layers
        self.input_layer = None
        self.mapping_layer = None
        self.resolver_layer = None
        self.transports_layer = None
        self.logging_layer = None
        
        # Catalogs
        self.mapping_catalog = None
        self.device_catalog = None
        
    async def initialize(self):
        """Initialize the application"""
        try:
            # Load configuration
            await self._load_config()
            
            # Setup logging
            self._setup_logging()
            
            # Initialize catalogs
            await self._initialize_catalogs()
            
            # Initialize layers
            await self._initialize_layers()
            
            # Start MQTT broker
            self._start_mqtt_broker()
            
        except Exception as e:
            print(f"Failed to initialize IoT Data Bridge: {e}")
            sys.exit(1)
    
    async def _load_config(self):
        """Load configuration from YAML file"""
        config_file = Path(self.config_path)
        if not config_file.exists():
            raise FileNotFoundError(f"Configuration file not found: {self.config_path}")
        
        with open(config_file, 'r', encoding='utf-8') as f:
            config_data = yaml.safe_load(f)
        
        self.config = AppConfig(**config_data)
    
    def _setup_logging(self):
        """Setup structured logging"""
        # Custom formatter for console logs (same as file format)
        def console_formatter(logger, method_name, event_dict):
            """Console formatter matching file log format"""
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            message = event_dict.get('event', '')
            
            # Extract key fields
            device_id = event_dict.get('device_id', '')
            object_name = event_dict.get('object', '')
            value = event_dict.get('value', '')
            
            # Show Data sent logs in console with proper format
            if message == "Data sent" and device_id and object_name and value != '':
                return f"Data sent | device_id={device_id} | object={object_name} | value={value}"
            else:
                # Show other important logs normally
                return message
        
        structlog.configure(
            processors=[
                structlog.stdlib.filter_by_level,
                structlog.stdlib.add_log_level,
                structlog.processors.TimeStamper(fmt="%H:%M:%S"),
                structlog.processors.format_exc_info,
                structlog.processors.UnicodeDecoder(),
                console_formatter
            ],
            context_class=dict,
            logger_factory=structlog.stdlib.LoggerFactory(),
            wrapper_class=structlog.stdlib.BoundLogger,
            cache_logger_on_first_use=True,
        )
        
        # Setup file logging
        log_file = Path(self.config.logging.file)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=getattr(logging, self.config.logging.level.upper()),
            format='%(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
        
        self.logger = structlog.get_logger("iot_data_bridge")
        
    
    async def _initialize_catalogs(self):
        """Initialize mapping and device catalogs"""
        self.mapping_catalog = MappingCatalog(self.config.mapping_catalog_path)
        await self.mapping_catalog.load()
        
        self.device_catalog = DeviceCatalog(self.config.device_catalog_path)
        await self.device_catalog.load()
    
    async def _initialize_layers(self):
        """Initialize all layers"""
        # Initialize logging layer first
        self.logging_layer = LoggingLayer(self.config.logging)
        
        # Initialize transports layer
        self.transports_layer = TransportsLayer(
            self.config.transports,
            self.device_catalog,
            self._log_device_ingest
        )
        
        # Initialize resolver layer
        self.resolver_layer = ResolverLayer(
            self.device_catalog,
            self._log_middleware_event
        )
        
        # Set resolver -> transports callback
        self.resolver_layer.set_transports_callback(self._handle_resolved_event)
        
        # Initialize mapping layer
        self.mapping_layer = MappingLayer(
            self.mapping_catalog,
            self._handle_mapped_event
        )
        
        # Initialize input layer (MQTT only)
        self.input_layer = InputLayer(
            self.config.input,
            self._handle_ingress_event
        )
    
    async def _handle_ingress_event(self, event: IngressEvent):
        """Handle ingress event from input layer"""
        # Extract raw data for logging
        raw_payload = event.raw.get('payload', {})
        equip_tag = raw_payload.get('Equip.Tag', 'Unknown')
        message_id = raw_payload.get('Message.ID', 'Unknown')
        raw_value = raw_payload.get('VALUE', 'Unknown')
        
        # No console log - only file log
        await self.mapping_layer.map_event(event)
    
    async def _handle_mapped_event(self, event: MappedEvent):
        """Handle mapped event from mapping layer"""
        # No console log - only file log
        await self.resolver_layer.resolve_event(event)
    
    async def _handle_resolved_event(self, event: ResolvedEvent):
        """Handle resolved event from resolver layer"""
        # No console log - only file log
        await self.transports_layer.send_to_devices(event)
    
    async def _log_middleware_event(self, event: MiddlewareEventLog):
        """Log middleware event"""
        await self.logging_layer.log_middleware_event(event)
    
    async def _log_device_ingest(self, event: DeviceIngestLog):
        """Log device ingest event"""
        await self.logging_layer.log_device_ingest(event)
    
    async def start(self):
        """Start the application"""
        self.running = True
        
        try:
            # Start all layers
            await asyncio.gather(
                self.input_layer.start(),
                self.transports_layer.start(),
                self.logging_layer.start(),
                return_exceptions=True
            )
            
            # Keep running until stopped
            while self.running:
                await asyncio.sleep(1)
                
        except Exception as e:
            self.logger.error("Error in main loop", error=str(e))
            raise
    
    async def stop(self):
        """Stop the application"""
        self.running = False
        
        # Stop all layers
        if self.input_layer:
            await self.input_layer.stop()
        if self.transports_layer:
            await self.transports_layer.stop()
        if self.logging_layer:
            await self.logging_layer.stop()
        
        # Stop MQTT broker
        self._stop_mqtt_broker()
    
    def _start_mqtt_broker(self):
        """Start MQTT broker"""
        import subprocess
        import os
        
        try:
            # Stop any existing mosquitto processes (silently ignore errors)
            try:
                subprocess.run(["pkill", "mosquitto"], check=False, capture_output=True)
            except:
                pass
            
            # Get the directory where mosquitto.conf is located
            # Try multiple possible locations
            possible_paths = [
                Path(self.config_path).parent / "mosquitto.conf",  # config/mosquitto.conf
                Path("mosquitto.conf"),  # current directory
                Path("../mosquitto.conf"),  # parent directory
            ]
            
            mosquitto_conf = None
            for path in possible_paths:
                if path.exists():
                    mosquitto_conf = path
                    break
            
            if not mosquitto_conf:
                print(f"Warning: mosquitto.conf not found. Searched: {[str(p) for p in possible_paths]}")
                return
            
            # Start mosquitto with the config file
            result = subprocess.run([
                "mosquitto", 
                "-c", str(mosquitto_conf), 
                "-d"
            ], cwd=str(mosquitto_conf.parent), capture_output=True, text=True)
            
            if result.returncode == 0:
                pass  # MQTT broker started successfully
            else:
                print(f"Failed to start MQTT broker: {result.stderr}")
                
        except FileNotFoundError:
            print("Warning: mosquitto not found. Please install mosquitto or start MQTT broker manually.")
        except Exception as e:
            print(f"Error starting MQTT broker: {e}")
    
    def _stop_mqtt_broker(self):
        """Stop MQTT broker"""
        import subprocess
        try:
            subprocess.run(["pkill", "mosquitto"], check=False, capture_output=True)
        except Exception as e:
            pass
    
    def setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown"""
        def signal_handler(signum, frame):
            asyncio.create_task(self.stop())
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)


async def main():
    """Main entry point"""
    app = IoTDataBridge()
    
    try:
        await app.initialize()
        app.setup_signal_handlers()
        await app.start()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"Application error: {e}")
        sys.exit(1)
    finally:
        await app.stop()


if __name__ == "__main__":
    asyncio.run(main())