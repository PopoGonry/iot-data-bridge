"""Data models for IoT Data Bridge"""

