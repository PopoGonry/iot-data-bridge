"""
IoT Data Bridge - External data to Device mapping middleware
"""

__version__ = "0.1.0"
__author__ = "IoT Data Bridge Team"

