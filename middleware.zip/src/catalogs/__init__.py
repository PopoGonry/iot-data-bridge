"""Catalog modules for IoT Data Bridge"""
